# Never Judge - Goodreads Cover Replacement

A Firefox extension that leverages the new `image-to-text` ML inference API to replace Goodreads book cover images with AI-generated descriptions.

## Installation 🛠️

1. **Clone the repository:**

    ```bash
    git clone https://github.com/your-username/GoodreadsCoverAI.git
    cd GoodreadsCoverAI
    ```

2. **Load the extension in Firefox:**

    - Open `about:debugging#/runtime/this-firefox`.
    - Click "Load Temporary Add-on".
    - Select the `manifest.json` file from the project folder.

3. **Enable Experimental ML Features:**

    - In Firefox Nightly, navigate to `about:config`.
    - Set `browser.ml.enable` and `extensions.ml.enabled` to `true`.
    - Ensure you grant the `trialML` permission in `about:addons` if prompted.

## How It Works

-   The extension targets Goodreads pages and selects cover images.
-   It fetches each cover image, runs it through Firefox's ML inference API, and replaces the image with a styled div containing the generated text.

## License 📜

This project is licensed under the MIT License.

## Notes

-   Ensure your Firefox version supports the `ml` permission and the `image-to-text` API.
-   Adjust the image selector if Goodreads updates their DOM structure.
